let username = "i3C8Y_UWATERLOO_CA_AUT";
let encodedPassword = "UNYkk7S+VPiPcQDSeZ9hpQ==";